use super::area::Area;

// use super::rect::Rectangle;
use super::collisions::{Contains, PointIter, Points};

use std::f64::consts::PI;
use std::fmt::Display;

pub struct Circle {
    pub x: f64,
    pub y: f64,
    pub radius: f64,
}

// impl Circle {
//     pub fn contains_point(&self, (x, y): (f64, f64)) -> bool {
//         let dx = x - self.x;
//         let dy = y - self.y;
//         dx * dx + dy * dy <= self.radius * self.radius
//     }
// }

impl Contains for Circle {
    fn contains_point(&self, (x, y): (f64, f64)) -> bool {
        let dx = x - self.x;
        let dy = y - self.y;
        dx * dx + dy * dy <= self.radius * self.radius
    }
}

impl Points for Circle {
    fn points(&self) -> PointIter {
        vec![(self.x, self.y)].into()
    }
}

// impl Collidable<Rectangle> for Circle {
//     fn collide(&self, other: &Rectangle) -> bool {
//         for point in other {
//             if self.contains_point(point) {
//                 return true;
//             }
//         }
//         return false;
//     }
// }

// impl Collidable<Circle> for Circle {
//     fn collide(&self, other: &Circle) -> bool {
//         return self.contains_point((other.x, other.y)) || other.contains_point((self.x, self.y));
//     }
// }

impl Area for Circle {
    fn area(&self) -> f64 {
        return self.radius * self.radius * PI;
    }
}

impl Display for Circle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        return write!(f, "Circle({}, {}), r={}", self.x, self.y, self.radius);
    }
}
