mod shapes;
use anyhow::Result;

use shapes::{
    circle::Circle,
    collisions::{Collidable, Contains, Points},
    rect::Rectangle,
};
use std::{fmt::Display, str::FromStr};

impl FromStr for Rectangle {
    type Err = anyhow::Error;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let parts = s.split(" ").collect::<Vec<_>>();
        if parts.len() != 4 {
            return Err(anyhow::anyhow!("bad rectangle"));
        }
        return Ok(Rectangle {
            x: parts[0].parse()?,
            y: parts[1].parse()?,
            width: parts[2].parse()?,
            height: parts[3].parse()?,
        });
    }
}

impl FromStr for Circle {
    type Err = anyhow::Error;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let parts = s.split(" ").collect::<Vec<_>>();
        if parts.len() != 3 {
            return Err(anyhow::anyhow!("bad circle"));
        }
        return Ok(Circle {
            x: parts[0].parse()?,
            y: parts[1].parse()?,
            radius: parts[2].parse()?,
        });
    }
}

enum Shape {
    Circle(Circle),
    Rectangle(Rectangle),
}

impl FromStr for Shape {
    type Err = anyhow::Error;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        let (shape, data) = s.split_once(" ").unwrap_or(("", ""));
        match shape {
            "rect" => return Ok(Shape::Rectangle(data.parse()?)),
            "circle" => return Ok(Shape::Circle(data.parse()?)),
            _ => return Err(anyhow::anyhow!("unknown shape")),
        }
    }
}

impl Points for &Shape {
    fn points(&self) -> shapes::collisions::PointIter {
        match self {
            Shape::Rectangle(rect) => return rect.points(),
            Shape::Circle(circ) => return circ.points(),
        }
    }
}

impl Contains for &Shape {
    fn contains_point(&self, point: (f64, f64)) -> bool {
        match self {
            Shape::Rectangle(rect) => return rect.contains_point(point),
            Shape::Circle(circ) => return circ.contains_point(point),
        }
    }
}

impl Display for &Shape {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Shape::Rectangle(rect) => return write!(f, "{}", rect),
            Shape::Circle(circ) => return write!(f, "{}", circ),
        }
    }
}

fn main() -> Result<()> {
    let file = std::fs::read_to_string("src/shape_file.txt")?;
    let shapes = file
        .lines()
        .filter_map(|line| line.parse().ok())
        .collect::<Vec<Shape>>();

    let collisions: Vec<(&Shape, &Shape)> = shapes
        .iter()
        .skip(1)
        .zip(shapes.iter().take(shapes.len() - 1))
        .filter(|(a, b)| a.collide(b))
        .collect();

    for (a, b) in collisions {
        println!("Collision: {} {}", a, b);
    }

    return Ok(());
}
