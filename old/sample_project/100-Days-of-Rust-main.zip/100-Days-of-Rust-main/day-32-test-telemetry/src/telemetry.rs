use tracing::Subscriber;
use tracing::subscriber::set_global_default;
use tracing_bunyan_formatter::{BunyanFormattingLayer, JsonStorageLayer};
use tracing_log::LogTracer;
use tracing_subscriber::{EnvFilter, Registry, layer::SubscriberExt};

pub fn get_subscriber(name: String, env_filter: String) -> impl Subscriber + Send + Sync {
    let env_filter =
        EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new(env_filter));
    let formatting_layer = BunyanFormattingLayer::new(name, std::io::stdout);
    Registry::default()
        .with(env_filter)
        .with(JsonStorageLayer)
        .with(formatting_layer)
}

pub fn init_subscriber(subscriber: impl Subscriber + Send + Sync) {
    LogTracer::init().expect("Failed to set logger");
    set_global_default(subscriber).expect("Failed to set subscriber");
}

// // ⛳️ Step 1 - Logs For Integration Tests

// use tracing::Subscriber;
// use tracing::subscriber::set_global_default;
// use tracing_bunyan_formatter::{BunyanFormattingLayer, JsonStorageLayer};
// use tracing_log::LogTracer;
// use tracing_subscriber::fmt::MakeWriter;
// use tracing_subscriber::{EnvFilter, Registry, layer::SubscriberExt};

// pub fn get_subscriber<Sink>(
//     name: String,
//     env_filter: String,
//     sink: Sink,
// ) -> impl Subscriber + Send + Sync
// where
//     // This "weird" syntax is a higher-ranked trait bound (HRTB)
//     // It basically means that Sink implements the `MakeWriter`
//     // trait for all choices of the lifetime parameter `'a`
//     // Check out https://doc.rust-lang.org/nomicon/hrtb.html
//     // for more details.
//     Sink: for<'a> MakeWriter<'a> + Send + Sync + 'static,
// {
//     let env_filter =
//         EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new(env_filter));
//     // let formatting_layer = BunyanFormattingLayer::new(name, std::io::stdout);
//     let formatting_layer = BunyanFormattingLayer::new(name, sink);
//     Registry::default()
//         .with(env_filter)
//         .with(JsonStorageLayer)
//         .with(formatting_layer)
// }

// pub fn init_subscriber(subscriber: impl Subscriber + Send + Sync) {
//     LogTracer::init().expect("Failed to set logger");
//     set_global_default(subscriber).expect("Failed to set subscriber");
// }
