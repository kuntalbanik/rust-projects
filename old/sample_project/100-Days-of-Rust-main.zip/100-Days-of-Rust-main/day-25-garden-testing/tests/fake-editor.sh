echo "testing" >> $1;
