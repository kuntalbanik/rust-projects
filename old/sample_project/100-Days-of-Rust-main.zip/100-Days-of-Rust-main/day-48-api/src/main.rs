#[macro_use]
extern crate rocket;
use rocket::response::status;
use rocket::serde::json::{json, Value};

#[get("/rustaceans")]
fn get_rustaceans() -> Value {
    json!([{"id": 1, "name": "John Doe"}, {"id": 2, "name": "Jane Doe"}])
}

#[get("/rustaceans/<id>")]
fn view_rustacean(id: usize) -> Value {
    json!({"id": id, "name": ""})
}

#[post("/rustaceans", format = "json")]
fn create_rustacean() -> Value {
    json!({"id": 3, "name": "joe", "email": "j@x.com"})
}

#[put("/rustaceans/<id>", format = "json")]
fn update_rustacean(id: usize) -> Value {
    json!({"id": id, "name": ""})
}

#[delete("/rustaceans/<_id>")]
fn delete_rustacean(_id: usize) -> status::NoContent {
    status::NoContent
}

#[catch(404)]
fn not_found() -> Value {
    json!("Not found!")
}
#[rocket::main]
async fn main() {
    let _ = rocket::build()
        .mount(
            "/",
            routes![
                get_rustaceans,
                view_rustacean,
                create_rustacean,
                update_rustacean,
                delete_rustacean
            ],
        )
        .register("/", catchers![not_found])
        .launch()
        .await;
}
