use super::area::Area;
// use super::circle::Circle;
use super::collisions::{Contains, PointIter, Points};
use std::fmt::Display;

pub struct Rectangle {
    pub x: f64,
    pub y: f64,
    pub width: f64,
    pub height: f64,
}

// impl Rectangle {
//     pub fn contains_point(&self, (x, y): (f64, f64)) -> bool {
//         return self.x <= x && x <= self.x + self.width && self.y <= y && y <= self.y + self.height;
//     }
// }

impl Contains for Rectangle {
    fn contains_point(&self, (x, y): (f64, f64)) -> bool {
        return self.x <= x && x <= self.x + self.width && self.y <= y && y <= self.y + self.height;
    }
}

impl Points for Rectangle {
    fn points(&self) -> PointIter {
        return vec![
            (self.x, self.y),
            (self.x, self.y + self.height),
            (self.x + self.width, self.y),
            (self.x + self.width, self.y + self.height),
        ]
        .into();
    }
}

// impl Collidable<Rectangle> for Rectangle {
//     fn collide(&self, other: &Rectangle) -> bool {
//         for point in other {
//             if self.contains_point(point) {
//                 return true;
//             }
//         }
//         return false;
//     }
// }

// impl Collidable<Circle> for Rectangle {
//     fn collide(&self, other: &Circle) -> bool {
//         return other.contains_point((other.x, other.y));
//     }
// }

impl Area for Rectangle {
    fn area(&self) -> f64 {
        return self.width * self.height;
    }
}

impl Default for Rectangle {
    fn default() -> Self {
        return Rectangle {
            x: 0f64,
            y: 0f64,
            width: 10f64,
            height: 10f64,
        };
    }
}

impl Display for Rectangle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        return write!(
            f,
            "Rectangle({}, {}), {}x{}",
            self.x, self.y, self.width, self.height
        );
    }
}
