mod shapes;
use shapes::circle::Circle;
use shapes::rect::Rectangle;

use crate::shapes::area::Area;
use crate::shapes::collisions::Collidable;

// pub struct RectIter {
//     points: Vec<(f64, f64)>,
//     idx: usize,
// }

// impl Iterator for RectIter {
//     type Item = (f64, f64);

//     fn next(&mut self) -> Option<Self::Item> {
//         if self.idx >= self.points.len() {
//             return None;
//         }
//         let point = self.points[self.idx];
//         self.idx += 1;
//         return Some(point);
//     }
// }

// impl RectIter {
//     fn new(rect: &Rectangle) -> Self {
//         return RectIter {
//             points: vec![
//                 (rect.x, rect.y),
//                 (rect.x, rect.y + rect.height),
//                 (rect.x + rect.width, rect.y),
//                 (rect.x + rect.width, rect.y + rect.height),
//             ],
//             idx: 0,
//         };
//     }
// }

// impl From<&Rectangle> for RectIter {
//     fn from(value: &Rectangle) -> Self {
//         return RectIter {
//             points: vec![
//                 (value.x, value.y),
//                 (value.x, value.y + value.height),
//                 (value.x + value.width, value.y),
//                 (value.x + value.width, value.y + value.height),
//             ],
//             idx: 0,
//         };
//     }
// }

// impl IntoIterator for &Rectangle {
//     type Item = (f64, f64);
//     type IntoIter = RectIter;

//     fn into_iter(self) -> Self::IntoIter {
//         // return RectIter::new(&self);
//         return self.into();
//     }
// }

fn main() {
    // let circle = Circle {
    //     x: 0f64,
    //     y: 0f64,
    //     radius: 4f64,
    // };

    // let rect = Rectangle {
    //     x: 0f64,
    //     y: 0f64,
    //     width: 2f64,
    //     height: 8f64,
    // };

    // println!("area: {}", rect.area());
    // println!("area: {}", circle.area());

    let rect = Rectangle::default();
    let rect2 = Rectangle::default();

    let circle = Circle {
        x: 0f64,
        y: 0f64,
        radius: 4f64,
    };

    let circle2 = Circle {
        x: 0f64,
        y: 0f64,
        radius: 4f64,
    };

    rect.collide(&rect2);
    circle.collide(&circle2);

    println!("area: {}", rect.area());
}
